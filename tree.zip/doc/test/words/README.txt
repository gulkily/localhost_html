these texts are saved from the short-lived words.bash.org.ru

eventually, they may be translated to english.

this site had some very good ideas.
