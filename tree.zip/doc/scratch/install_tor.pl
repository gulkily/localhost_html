#!/usr/bin/perl

# check if sudo
#	if not, tell user they should be
#
# check if torrc
#	if torrc, check if our setup is there
#		if not there:
#			add
#			restart server
#
	
