#!/bin/sh

echo "rm -rfv config/template/*"
rm -rfv config/template/*

echo "rm -rfv config/theme/*"
rm -rfv config/theme/*

#./config_check.sh