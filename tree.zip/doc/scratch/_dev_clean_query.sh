#!/bin/sh

# this script will clean config/template/query

echo "rm -vrf config/template/query/"
rm -vrf config/template/query/

echo "================================="
echo "Cleanup of config/template/query complete!"
echo "================================="
