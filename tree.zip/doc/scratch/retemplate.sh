#!/bin/sh

./config/template/perl/pages.pl --system -M chain --listing
