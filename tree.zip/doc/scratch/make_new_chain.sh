#!/bin/sh

grep f938d02ef6ab1eb80ff6b3a35f5923a5a9107e39 /home/manjaro/hike/html/txt/oldchain.txt >> /home/manjaro/hike/html/txt/newchain.txt &
