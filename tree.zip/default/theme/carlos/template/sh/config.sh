#!/bin/sh

echo 0 > config/setting/html/menu_top
echo 0 > config/setting/html/menu_bottom
echo 0 > config/setting/admin/js/loading
echo 0 > config/setting/html/css_theme_concat
