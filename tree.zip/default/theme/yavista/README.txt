this theme depends on and extends chicago theme
