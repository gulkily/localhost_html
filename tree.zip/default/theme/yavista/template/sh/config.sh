#!/bin/sh

echo 0 > config/setting/html/menu_top
echo 0 > config/setting/html/menu_bottom
echo 0 > config/setting/html/item_page/toolbox_publish
echo 0 > config/setting/html/item_page/toolbox_search
echo 1 > config/setting/html/monochrome
echo 1 > config/setting/admin/js/openpgp_keygen_prompt_for_username
echo 1 > config/setting/admin/js/loading
echo "Pray..." > config/string/en/meditate
echo "#fff0ef" > config/setting/html/color/background
echo "#403000" > config/setting/html/color/text