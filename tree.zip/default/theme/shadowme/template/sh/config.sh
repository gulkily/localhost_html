#!/bin/sh

echo 0 > config/setting/admin/js/dragging
echo 1 > config/setting/admin/php/route_insert_cookie_fingerprint