#!/usr/bin/perl -T

use warnings;
use strict;

sub GetBoxesPage {
	WriteLog('GetBoxesPage()');
	return 'hi';
}

1;
