javascript:window.location='http://localhost:2784/post.html?comment='+encodeURIComponent(window.getSelection())+'&s='+encodeURIComponent(document.location)
