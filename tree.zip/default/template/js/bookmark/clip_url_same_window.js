//javascript:
void(
	window.location =
		'http://localhost:2784/post.html?comment=' +
		encodeURIComponent( document.location )
	;
)