if (0) {
	var gt = unescape('%3E');
	document.write('<span' + gt + '<a href="#$itemEndAnchor" style="color: $colorTitlebarText;" class=skip title=skip onclick="if (window.CollapseWindowFromButton) { return CollapseWindowFromButton(this); } return false;"' + gt + '$btnCloseCaption</a' + gt + '</span' + gt + '');
}