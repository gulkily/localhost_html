<HEAD>
<SCRIPT LANGUAGE="JavaScript">
<!--
function BodyOnLoad() {
//	document.write(navigator.userAgent);
	alert('BodyOnLoad()');
}
//-->
</SCRIPT>

<style type="text/css">
<!--

// -->
</style>

</HEAD>

<BODY onLoad="BodyOnLoad()">

<p>This is test.</p>

<script><!--
document.write('<p>' + navigator.userAgent + '</p>');
document.write('<p>window.localStorage:' + window.localStorage + '</p>');
document.write('<p>document.getElementsByClassName:' + document.getElementsByClassName + '</p>');
// --></script>

</BODY>

