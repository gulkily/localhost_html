// == begin post.js
function makeRefLink() {
	if (document.getElementById && document.referrer) {
		var retRef = document.getElementById('retRef');
		if (retRef) {
			retRef.innerHTML = '<a href=\"' + document.referrer + '\"' + String.fromCharCode(62) + 'Return to Previous Page</a' + String.fromCharCode(62) + ' ';
//			window.open(document.referrer + '?', '_self');
		}
	}
}
// == end post.js