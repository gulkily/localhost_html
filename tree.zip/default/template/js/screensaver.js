// == begin screen_saver.js

// == end screen_saver.js