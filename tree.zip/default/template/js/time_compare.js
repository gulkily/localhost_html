<!-- time_compare.js -->

<!-- displays server time vs client time information -->

<!-- time_compare.js -->
