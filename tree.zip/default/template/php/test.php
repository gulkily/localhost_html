#!/bin/php
<html>
<?php

include_once('utils.php');

print_r( '<pre>'.GpgParse('html/txt/84/a7/84a786bfeec5caf837f1f8941183eac169deb80a.txt').'</pre>');


print_r('<pre>'.GpgParse('admin.key').'</pre>');


print_r(WriteLog(''));

