<?php
//
//function StripAdvanced ($html) {
////	$html = preg_replace('/\<input [^>]+class=advanced[^>]*\>/', '', $html);
////	$html = preg_replace('/\<a [^>]+class=advanced[^>]+\>[^\<]+\<\/a\>/', '', $html);
////	$html = preg_replace('/\<span[^>]+class=advanced[^>]*\>.+<\/span\>/', '', $html);
//
////	$html = preg_replace('/\<.+\Wclass=advanced.+>/', 'xx', $html);
////	$html = preg_replace('/\<span.+\Wclass=advanced\>.+\<\/span\>/', 'xx', $html);
////	$html = preg_replace('/\<span.+\Wclass=advanced.+\>.+\<\/span\>/', 'xx', $html);
//	//$html = preg_replace('/\<span.+>.+\<\/span\>/s', 'xx', $html);
//
//	return $html;
//}
//
//function StripHeavyTags ($html) {
//	$tags = array('table', 'td', 'span', 'fieldset', 'legend');
//
//	foreach ($tags as $tag) {
//		$html = preg_replace('/\<'.$tag.'[^>]+\>/', '', $html);
//		$html = preg_replace('/\<\/'.$tag.'\>/', '', $html);
//	}
//
//	{
//		$html = preg_replace('/\<tr[^>]+\>/', '', $html);
//		$html = preg_replace('/\<\/tr\>/', '<br>', $html);
//	}
//
//	return $html;
//}
//
//function StripComments ($html) {
//	$html = preg_replace('/\<\!--[^>]+\>/', '', $html);
//
//	return $html;
//}
//
//function StripWhitespace ($html) {
//	$html = preg_replace('/[\t\n ]+/', ' ', $html);
//
//	return $html;
//}
//
//$settings = file_get_contents('settings.html');
////$settings = StripAdvanced($settings);
////$settings = StripHeavyTags($settings);
////$settings = StripComments($settings);
////$settings = StripWhitespace($settings);
//
////print $settings;
//
//$index0 = file_get_contents('index0.html');
////$index0 = StripAdvanced($index0);
//$index0 = StripHeavyTags($index0);
//$index0 = StripComments($index0);
//$index0 = StripWhitespace($index0);
//
//print $index0;