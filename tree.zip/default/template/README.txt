default/template/
=================

Note: This directory contains default templates.
                                =======

If you're not sure what that means,


you should probably be here: config/template/
                             ======
