#!/usr/bin/perl -T

use strict;
use warnings;
use 5.010;
use utf8;

1;