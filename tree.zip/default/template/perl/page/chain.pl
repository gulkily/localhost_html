#!/usr/bin/perl -T

use strict;
use warnings;
use 5.010;

sub GetChainPage {
	return 'chain page placeholder'
}

1;
