#!/usr/bin/perl -T

use strict;
use warnings;

use 5.010;

sub GetRandomPage {
# sub MakeRandomPage {
	return 'random page placeholder';
	# look at MakePage() instead
}

1;
