#!/usr/bin/perl -T

use strict;
use warnings;
use 5.010;
use utf8;

require './utils.pl';
require_once('sqlite.pl');

