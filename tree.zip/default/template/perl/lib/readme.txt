lib/

Perl libraries which are sometimes not included in distros.

You can safely ignore this directory, it will soon move under default.
