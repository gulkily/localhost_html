insert into vote_value(vote, value) values('good', 1);

insert into vote_value(vote, value) values('like', 1);

insert into vote_value(vote, value) values('pubkey', 1);

insert into vote_value(vote, value) values('textart', 1);

insert into vote_value(vote, value) values('meta', 1);

insert into vote_value(vote, value) values('mourn', 9001);

insert into vote_value(vote, value) values('textart', 1);

insert into vote_value(vote, value) values('noise', -1);

insert into vote_value(vote, value) values('funny', 1);

insert into vote_value(vote, value) values('signed', 1);

insert into vote_value(vote, value) values('person', 9001);

insert into vote_value(vote, value) values('puzzle', 9000);

insert into vote_value(vote, value) values('approve', 10);

insert into vote_value(vote, value) values('thanks', 1);

insert into vote_value(vote, value) values('flag', -50000);

insert into vote_value(vote, value) values('scunthorpe', -1);

insert into vote_value(vote, value) values('stop', -1023);

insert into vote_value(vote, value) values('hide', -1023);

insert into vote_value(vote, value) values('report', -1023);

