these are config templates for mc (midnight commander)
