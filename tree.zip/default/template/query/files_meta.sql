select file_path from item_flat where ','||tags_list||',' like '%,meta,%';
