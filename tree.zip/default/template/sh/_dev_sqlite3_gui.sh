#!/bin/sh

# opens index database from cache in sqlitebrowser

sqlitebrowser ./cache/*/index.sqlite3
